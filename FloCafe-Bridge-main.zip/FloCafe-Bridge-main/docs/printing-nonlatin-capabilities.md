# Non-Latin thermal receipt printing — capability study and decision record

**Refs:** #446 (research issue) · epic #438
**Status of this document:** Study and decision record plus Phase 9 implementation boundary. The pure `GS v 0` contract, dedicated Chromium surface, and mixed-mode assembly are implemented behind the additive profile-owned raster capability. Current profiles declare raster capability in code, but broad script/font coverage and hardware fidelity remain evidence-gated (see Section 8, *Open decisions*). The current profile-owned text capability contract is documented in [printing-architecture.md §6](printing-architecture.md#6-printer-capability-model--warning-semantics).

---

## 1. Problem

Raw thermal printing of Arabic, Persian, and Urdu — and non-Latin scripts generally — remains limited by printer firmware and font coverage. The current runtime uses the shared profile-owned text capability contract described in [printing-architecture.md §6](printing-architecture.md#6-printer-capability-model--warning-semantics): generic native profiles remain ASCII-only, current profiles declare raster separately, and unsupported item or financial rows are refused before transport so a receipt is never printed with missing financial content. This document covers the implemented Phase 9 raster boundary and deferred broader script and hardware validation.

Why generic ESC/POS printers fail non-Latin text:

1. **Missing glyphs.** Cheap 58 mm / 80 mm clones carry small font ROMs covering CP437/CP850-class sets. Arabic, Hebrew, Devanagari, Thai, and CJK glyphs are absent, so bytes print as garbage or blank.
2. **No contextual shaping.** Arabic, Persian, and Urdu require contextual letter forms; printer firmware renders isolated forms at best.
3. **No bidirectional reordering.** Printers emit left-to-right only; logical-order RTL text prints reversed.
4. **Code pages do not save us** (evidence below).

The end-state contract from epic #438 is **no silent data loss**: native render, explicitly supported fallback, or an explicit warning/error — never quiet omission of financial content.

## 2. Method

- Runtime behavior claims were checked against the current implementation after #443/#473/#474/#472 landed; the current text-capability contract is owned by [printing-architecture.md §6](printing-architecture.md#6-printer-capability-model--warning-semantics).
- External evidence: Epson's official ESC/POS command reference, the ReceiptPrinterEncoder/escpos-php/python-escpos/node-thermal-printer issue trackers, Odoo's IoT printer driver source, and qzind/tray. Links inline.
- First-class user requirements come from real reports by @MaMaDTHUG82 (Iran, Meva TP-UN hardware): #437, #241, discussions #239/#326.

## 3. Approach comparison

### 3.1 Printer-native Arabic-script shaping (the profile capability)

The `capabilities.shaping.arabic` field means: *this specific printer's firmware performs contextual shaping and bidi ordering*. It must stay default-off and be set true only after a real print on the specific hardware proves shaped output. The legacy `arabicShaping` field is retained only as a compatibility input. Reality:

- Generic ESC/POS firmware does none of this. Even on models that accept Arabic bytes, output is isolated forms printed left-to-right unless the host pre-shapes and pre-reverses.
- The qzind/tray experience (Epson TM-T88VI + vendor utility + ICU mapping down to IBM864 with byte swapping) shows even best-case native support is model-specific and fragile ([ReceiptPrinterEncoder issue #26](https://github.com/NielsLeenheer/ReceiptPrinterEncoder/issues/26)).

**Verdict:** keep as an opt-in passthrough tier for proven hardware only. Not a general solution.

### 3.2 Printer-native Arabic code pages (CP1256 / CP720 / CP864 / kanji modes)

The current capability model supports only explicitly declared code pages and does not add hardware claims to shipped profiles. The analysis below concerns Arabic code pages and the deferred broad-script problem; Latin code-page handling and representability rules are owned by [printing-architecture.md §6](printing-architecture.md#6-printer-capability-model--warning-semantics).

- Epson's reference states the `FS &` kanji mode *"can be used only for the Japanese, Simplified Chinese, Traditional Chinese models, and Korean models"* — regional firmware variants our users do not own ([Epson ESC/POS reference](https://download4.epson.biz/sec_pubs/pos/reference_en/escpos/fs_ampersand.html)).
- Arabic code pages contain base/isolated glyph forms only → visibly broken letters for native readers; right-to-left ordering is still the host's problem.
- Table identity ≠ glyph layout across vendors; unmappable characters silently become `?` (iconv-lite translation in [node-thermal-printer PR #81](https://github.com/Klemen1337/node-thermal-printer/pull/81); [ReceiptPrinterEncoder #26](https://github.com/NielsLeenheer/ReceiptPrinterEncoder/issues/26)).

**Verdict:** dead end for quality; unmaintainable across clone vendors.

### 3.3 UTF-8 pass-through

Some modern firmware accepts raw multi-byte UTF-8 against internal fonts. Coverage and shaping vary per model and revision; there is no discovery mechanism, and cheap clones fail unpredictably. Useful as a *reported capability* on the hardware test matrix (Section 6), never as an assumed baseline.

### 3.4 Host-side shaping + bidi reordering before emission

Send pre-shaped presentation forms (Unicode Arabic Presentation Forms-B) in visual order as text bytes.

| Criterion | Assessment |
| --- | --- |
| Printer requirement | Printer must accept multi-byte UTF-8 **and** have glyphs for the shaped codepoints. Cheap clones fail both — shaped Arabic arrives as U+FE7x–U+FExx which their font ROMs lack. |
| Fidelity | Correct *when* glyphs exist; host must reverse visual order itself. |
| Mixed-script rows | Hard: visual-order strings break column math and truncation (cutting visual order cuts the logical start). The kernel's LTR-island model helps alignment, not truncation. |
| Dependency footprint | Lightweight tier exists: `bidi-js` (~20 kB pure JS) plus an Arabic reshaper covers Arabic/Hebrew receipts. Full HarfBuzz via WASM (`harfbuzzjs`, subset build ≈ 613 kB) is only needed for complex Indic/Khmer conjuncts. |

**Verdict:** a *necessary component* of any non-Latin pipeline (something must produce correctly shaped, ordered pixels), but **insufficient alone** — it does not reach printers without the glyphs.

### 3.5 Raster rendering (`GS v 0`)

Render the receipt (or parts) to a 1-bit bitmap and print it with `GS v 0 m xL xH yL yH`.

- `GS v 0` is the mechanism every printer uses for logos; it is implemented across the entire ESC/POS clone ecosystem, including the cheapest hardware. Density mode `m=0` (8 dots/mm both axes) matches standard 203 dpi receipt heads.
- Reference implementation scale test: Odoo's IoT box converts every receipt image to greyscale → 1-bit → `GS v 0` → cut ([odoo/odoo `PrinterDriver.print_receipt`](https://github.com/odoo/odoo/blob/master/addons/iot_drivers/iot_handlers/drivers/printer_driver_base.py)); their commit replacing the old ESC/POS text encoder states: *"We now transform the receipts to JPGs, transform these JPGs into ESCPOS commands and send them via Cups."* This runs across one of the largest heterogeneous open-source POS fleets in existence.

| Criterion | Assessment |
| --- | --- |
| Printer requirement | Effectively universal (logo path). |
| Fidelity | Pixel-exact for any script, digits, mixed-direction rows, logos. Shaping/bidi correctness becomes whatever the host canvas draws — the browser/canvas applies the Unicode bidi algorithm natively. |
| Mixed-script correctness | Trivial: no column math on RTL text; truncation becomes measured pixel width with ellipsis. |
| Performance | Payload grows from ~1–2 KB (text receipt) to ≈ 72 B × ~1150 dot rows ≈ 80 KB (80 mm) / ≈ 55 KB (58 mm). Transfer over TCP 9100 / USB bulk is sub-second; head time is unchanged because the same paper area prints either way. Slow MCUs on clones can stutter on very large single images — solved by banding (Section 5). |
| Paper width / density | Requires dots-per-line knowledge: 384 (58 mm) vs 576 (80 mm) at 203 dpi. Derivable from the existing paper-width profile data. |
| Transport support | The shared raster assembly produces equivalent bytes for TCP, USB RAW queues, and WebUSB; WebUSB uses a typed document bridge. OS spooler RAW pass-through is proven by Odoo/CUPS. |
| Package size impact | None at the protocol layer. Phase 9 adds no production rendering dependency; a separately reviewed bundled font or local fallback and hardware probe remain required before claiming specific script coverage. |
| Maintenance burden | One renderer consuming the semantic print kernel; new scripts become font additions, not logic changes. |
| Failure/fallback mode | Disabled or failed raster retains native output for eligible content; unsupported non-financial lines warn and unsupported financial units refuse before transport. Never silently loses financial content. |

**Verdict:** the only approach satisfying "universal system that supports ALL printers".

### 3.6 HTML/browser fallback

The browser print path already renders every script correctly (the browser does shaping and bidi). It remains a steering target when raw printing is unacceptable, but it cannot serve instant raw-cut workflows, KOT station routing, or spooler-free checkout speed. Out of scope for further comparison.

### 3.7 Criteria matrix summary

| Approach | Works on cheap clones | Correct Arabic/Persian | Mixed rows | Transport coverage | Extra deps | Failure mode |
| --- | --- | --- | --- | --- | --- | --- |
| Native shaping flag | ✗ rare | ✓ only on proven units | partial | all | none | garbled/skip |
| Native code pages | ✗ | ✗ isolated forms | ✗ | all | none | garbage, `?` |
| UTF-8 pass-through | varies | varies | varies | all | none | mojibake |
| Host shaping + bidi text | ✗ (glyph gap) | partial | hard | all | small | blank/garbage |
| **Raster `GS v 0`** | **✓** | **✓** | **✓** | **all raw transports** | none in Phase 9; bundled font validation required | native fallback or skip/refuse |

## 4. What other systems do

| System | Multilingual receipt strategy | Evidence |
| --- | --- | --- |
| Odoo POS (IoT box) | Whole-receipt raster for everything; old ESC/POS text encoder retired | [`PrinterDriver.print_receipt` source](https://github.com/odoo/odoo/blob/master/addons/iot_drivers/iot_handlers/drivers/printer_driver_base.py), [hw_escpos replacement commit](https://github.com/odoo/odoo/commit/03b2f7b77dc6189bb485e0b834dba5f6d3d4da2c) |
| escpos-php | Unicode→code-page auto-mapping; official Arabic example renders **images** instead of text lines | [Arabic example](https://github.com/mike42/escpos-php/blob/master/example/specific/6-arabic-epos-tep-220m.php) |
| python-escpos | Exposes charcode selection only; recurring Arabic mojibake issues resolved by users switching to raster | [#37](https://github.com/python-escpos/python-escpos/issues/37), [#633](https://github.com/python-escpos/python-escpos/issues/633) |
| node-thermal-printer | iconv-lite code-page translation; shaping/bidi unsupported; Arabic/Thai requests open for years | [PR #81](https://github.com/Klemen1337/node-thermal-printer/pull/81), [#180](https://github.com/Klemen1337/node-thermal-printer/issues/180) |
| ReceiptPrinterEncoder | Maintainer guidance: proper Arabic printing = draw a bitmap | [#26](https://github.com/NielsLeenheer/ReceiptPrinterEncoder/issues/26) |
| Loyverse | Prints through manufacturer SDKs, which render bitmaps internally on mobile | [supported printers](https://help.loyverse.com/help/supported-printers) |
| qzind/tray | ICU-based host shaping down to IBM864 + byte swap; author notes most projects give up and send rasters | [PR #339 discussion](https://github.com/qzind/tray/pull/339#issuecomment-404016953) |

Consensus: host-rendered bitmaps are the universal fallback; code pages are a dead end for Arabic/Persian.

### 3.8 Devanagari (Hindi)

Hindi is LTR, but it has the same class of hardware risk as other non-Latin scripts: printer firmware may lack glyphs, contextual shaping, and conjunct support. Hindi must not use the Arabic shaping capability switch, and a locale selection must not change a profile's raster capability. Browser HTML and the local Chromium raster surface are the full-Unicode paths when a system or bundled font is available. Native ESC/POS remains capability-gated, with unsupported financial units refused before transport. The shared width helper is grapheme-aware so Devanagari combining marks and conjuncts are not split at receipt-width boundaries.

**Verdict:** expose Hindi labels through the normal registry and print-label generator, keep profile capability flags unchanged, document the direct-thermal limitation, and require profile-specific font plus real-printer evidence before claiming native Indic support.

## 5. Recommended architecture (decision record)

**Primary approach: capability-tiered hybrid with raster as the universal guarantee.**

```
PrintDocument ──► renderer decides per line/block:
   Tier 1  Pure Latin/ASCII            → native ESC/POS text (unchanged bytes, fastest)
   Tier 2  Non-Latin + profile proves
           firmware shaping            → profile-owned `capabilities.shaping.arabic` passthrough
   Tier 3  Everything else             → host-shaped, bidi-correct RASTER band(s) via GS v 0
                                         [mixed mode when raster is enabled]
   Tier 4  Whole-receipt raster        → tested compatibility mode / fallback if mixed
                                         mode misbehaves on specific hardware
   Tier 5  Skip-with-warning           → retained last resort; never silent
```

Per transport: backend and WebUSB use equivalent validated semantic inputs and
the shared raster assembly; native bytes remain available for units that do not
need raster. The browser HTML path is unchanged.

Runtime implication of the legacy skip-with-warning path: when an enabled
profile selects raster, unsupported lines become complete raster units; when
raster is disabled or fails, skip-with-warning remains the non-financial
fallback and financial output is refused before transport.

Phase 9 implementation boundary:

- The dedicated [`main/printers/raster-renderer.ts`](../main/printers/raster-renderer.ts) surface consumes typed requests derived from semantic `PrintDocument`/`KotDocument` output; it is isolated from the ordinary POS page and accepts bundled local font data URLs only.
- Backend and WebUSB core receipt/KOT paths group semantic rows or blocks before raster selection, then assemble raster and native output through the shared [`shared/print/raster.ts`](../shared/print/raster.ts) contract.
- Raster capability flags live on `ThermalPrinterCapabilities.raster` and are supplied by `SupportedPrinterProfile`; current profiles declare the raster path, while profile-specific font and real-printer evidence remains required for a script or hardware claim.
- No production rendering dependency or remote font source was added.

Risks and mitigations:

| Risk | Mitigation |
| --- | --- |
| Print speed on slow MCU clones | Band images into ≤ ~200-dot-row strips; mixed mode keeps most of a typical Persian receipt native text. |
| Low-end printer memory | Same banding; Odoo ships whole-image raster across a huge fleet, so residual risk is low. |
| Density/DPI variance | Derive dots-per-line from paper width; verify visually via the test-page raster probe (Section 7). Avoid `m≠0` density modes until hardware-proven. |
| Cutter position | Existing feed-before-cut sequence retained (Odoo likewise uses feed + partial cut). |
| Baseline mismatch between native text lines and raster bands | Render bands at multiples of the 24-dot Font A line height; emulate double width/height by scaling pixels. |
| RTL truncation/column math | Disappears inside raster bands (pixel-measured ellipsis); kernel island logic continues to govern native-text alignment. |
| Regression risk for English receipts | Tier 1 keeps current byte streams; parity tests assert ASCII byte-identity (extends the #439 harness). |

## 6. Community hardware-test matrix checklist

Owners of real printers: run this checklist and report results (issue comment or discussion post) with a photo of each printout. One row per printer model.

```
Printer model:            Connection:      network / usb / webusb
Paper width:              58mm / 80mm      Firmware date (if known):

[ ] 1. ASCII text receipt prints cleanly (baseline)
[ ] 2. Test page prints; column ruler aligns to paper edges
[ ] 3. UTF-8 pass-through: paste of "فارسی Hello עברית ไทย हिन्दी"
       prints as…  correct / reversed / boxes / blank / garbage
       For Hindi, also test a conjunct and a combining matra, not only isolated letters.
[ ] 4. Code page probe (if the app exposes it): CP1256 result ___
[ ] 5. Firmware Arabic shaping probe: unshaped-but-reversed Persian
       looks connected?  yes / no
[ ] 6. Raster probe (test page band, Section 7): prints?  yes / no
[ ] 7. Raster width: solid bar spans full width except the small
       designed inset (~1mm/side)?  full / shrunk / clipped
[ ] 8. Banded raster (multi-strip image): continuous, no gaps/stutter?
[ ] 9. Mixed sample: Latin text lines + Persian raster lines interleave
       at consistent line height?
[ ] 10. Cut position correct after raster tail?  full / partial / failed
[ ] 11. Timing: text receipt ___ s ; raster receipt ___ s
[ ] 12. Photo(s) attached
```

Seed validators: @MaMaDTHUG82 (Meva TP-UN, Iran — reporter of #437), plus FloCafe customers in Morocco and India. Priority unknowns: whether budget clones handle banded `GS v 0` without stutter (expected yes), and which models mishandle non-default density modes.

## 7. Test-page raster probe specification

The diagnostic test-page enhancement is implemented but remains capability-gated: it is emitted only when the selected profile explicitly enables raster. The backend route accepts `rasterProbe: true` for an owner/manager test request and passes the selected profile capability; disabled profiles retain the existing test page unchanged. The probe gives remote users a single photo-based validation path:

1. After the existing ruler/edge-probe section, emit a solid black rectangle: `widthDots - 16` dots wide, 48 dot rows tall, as one `GS v 0` band (`m=0`, xL/xH = `(widthBytes)` little-endian, yL/yH = 48 little-endian).
2. Follow with a second band containing inverted checkerboard (8×8 dot cells) to reveal dithering/density misconfiguration.
3. Emit a third band scaled to half height (24 rows) to expose vertical density mismatch (`m=0` assumes square dots at 203 dpi).
4. Close with the standard feed + cut sequence so cutter position is validated in the same printout.
5. Expected result on healthy hardware: crisp solid bar, uniform checkerboard, correct proportions, clean cut. Any band missing, skewed, or stretched indicates a raster/density defect to report in the checklist above.

Implementation note: `buildRasterDiagnosticBands` in [`shared/print/raster.ts`](../shared/print/raster.ts) uses the profile-derived width and bounded height. The route sends the result through the same dispatch used by ordinary receipts, so TCP, OS RAW, USB, and WebUSB response semantics remain transport-neutral.

## 8. Open decisions requiring a human call

- **Rendering-engine dependency:** Phase 9 uses option (c), a dedicated renderer process over a narrow typed IPC boundary, with no production dependency added. The surface accepts bundled local font data URLs when configured and otherwise uses local fallback families; a separately reviewed font and hardware probe are still required before claiming a new script profile.
- Whether Tier 4 whole-receipt raster should ship as a user-facing compatibility toggle from day one or remain internal fallback until telemetry justifies exposure. The Phase 9 default remains mixed mode, with whole-receipt mode internal/tested only.

## 9. References

- Epson ESC/POS command reference, `FS &`: <https://download4.epson.biz/sec_pubs/pos/reference_en/escpos/fs_ampersand.html>
- ReceiptPrinterEncoder Arabic thread: <https://github.com/NielsLeenheer/ReceiptPrinterEncoder/issues/26>
- Odoo IoT printer driver: <https://github.com/odoo/odoo/blob/master/addons/iot_drivers/iot_handlers/drivers/printer_driver_base.py> · replacement rationale: <https://github.com/odoo/odoo/commit/03b2f7b77dc6189bb485e0b834dba5f6d3d4da2c>
- escpos-php Arabic example: <https://github.com/mike42/escpos-php/blob/master/example/specific/6-arabic-epos-tep-220m.php>
- node-thermal-printer code-page translation: <https://github.com/Klemen1337/node-thermal-printer/pull/81>
- python-escpos Arabic issues: <https://github.com/python-escpos/python-escpos/issues/37>, <https://github.com/python-escpos/python-escpos/issues/633>
- qzind/tray IBM864 approach: <https://github.com/qzind/tray/pull/339#issuecomment-404016953>
- Loyverse supported printers: <https://help.loyverse.com/help/supported-printers>
- FloCafe user cases: #437 (Persian items dropped from bills; Meva TP-UN), #241 (mixed-script bidi scramble example «برای شروع QR کد را اسکن کنید»; Persian digits/Toman/Shamsi preferences), discussions #239/#326.
